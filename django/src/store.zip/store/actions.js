// posts 
export const SET_POSTS = 'SET_POSTS';

// reset
export const RESET_STATE = 'RESET_STATE';